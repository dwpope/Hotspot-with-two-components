// This file holds the main code for plugins. Code in this file has access to
// the *figma document* via the figma global object.
// You can access browser APIs in the <script> tag inside "ui.html" which has a
// full browser environment (See https://www.figma.com/plugin-docs/how-plugins-run).

// This plugin creates rectangles on the screen.
const nodes: SceneNode[] = [];

// Import both components
Promise.all([
  figma.importComponentByKeyAsync('7473bc6b250a6792153b4482619b27b03b8f2bb8'), // Hotspot component
  figma.importComponentByKeyAsync('ANNOTATION_COMPONENT_KEY_HERE') // Replace with actual annotation component key
])
.then(([hotspotComponent, annotationComponent]) => {
  // Once we have the components, create instances for each selected node
  figma.currentPage.selection.forEach(node => {
    // Create Hotspot instance
    const hotspotInstance = hotspotComponent.createInstance();
    const absoluteBoundingBox = node.absoluteBoundingBox;
    
    if (absoluteBoundingBox) {
      hotspotInstance.x = absoluteBoundingBox.x;
      hotspotInstance.y = absoluteBoundingBox.y;
      hotspotInstance.resize(node.width, node.height);
      hotspotInstance.name = "Hotspot";

      // Create Annotation instance
      const annotationInstance = annotationComponent.createInstance();
      annotationInstance.name = "Annotation";
      
      // Position annotation above hotspot with 8px spacing
      annotationInstance.x = hotspotInstance.x; // Aligned to left edge
      annotationInstance.y = hotspotInstance.y - annotationInstance.height - 8; // 8px spacing

      // Add both instances to the page
      figma.currentPage.appendChild(hotspotInstance);
      figma.currentPage.appendChild(annotationInstance);
      
      // Add both instances to nodes array
      nodes.push(hotspotInstance);
      nodes.push(annotationInstance);
    }
  });

  // Update selection and viewport
  figma.currentPage.selection = nodes;
  figma.viewport.scrollAndZoomIntoView(nodes);
  
  // Close the plugin
  figma.closePlugin();
})
.catch(error => {
  // Handle any errors (e.g., component not found)
  figma.notify(`Error: ${error.message}`);
  figma.closePlugin();
});
